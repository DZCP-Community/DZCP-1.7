<?php
/**
 * <<Hammermaps.de Libraries>>
 * @package: DZCP Libraries for DZCP 1.7.x
 * @author: Hammermaps.de Developer Team
 * @link: http://www.hammermaps.de
 */

if(file_exists(basePath.'/inc/additional-kernel/addon_hmlib/common.php')) {
    if(!defined('basePathHMLib')) {
        define('basePathHMLib', basePath."/inc/additional-kernel/addon_hmlib");
    }
    require_once(basePath.'/inc/additional-kernel/addon_hmlib/common.php');
} else DebugConsole::insert_warning('additional-kernel/addon_hmlib.php', basePath.'/inc/additional-kernel/addon_hmlib/common.php not found!');