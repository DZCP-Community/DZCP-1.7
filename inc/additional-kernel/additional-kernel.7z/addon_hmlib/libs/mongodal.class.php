<?php
//--------- This code Has been written for other developers ---
// db_connect("Rss_feeder");// database name
// $items = array("id"=>"2","url"=>"foo");
// db_insert("cl_links",$items);
// db_delete("cl_links",array("id"=>"1"));
// db_update("cl_links",array("id"=>"1"),array("id"=>"1","url"=>"ehsan"),true);
// $a = db_find("cl_links",array("id"=>true,"url"=>true),array("id"=>"2"));
//----------------------------------
class MongoDAL {
	var $mongo = "";
	var $db = "";
	function db_connect($db_name)
	{
		global $mongo;
		global $db;
		$mongo = new MongoClient("mongodb://127.0.0.1");
		$db = $mongo->$db_name;
	}
	function db_insert($collection_name,$values)
	{
		global $db;
		$collection = $db->$collection_name;
		$collection->insert($values);
	}
	function db_delete($collection_name,$condition)
	{
		global $db;	
		$collection = $db->$collection_name;
		$collection->remove($condition);
	}
	function db_update($collection_name,$condition,$newdata)
	{
		global $db;
		$collection = $db->$collection_name;
		$collection->update($condition,$newdata);
	}
	function db_findone($collection_name,$condition,$field_name)
	{
		global $db;
		$collection = $db->$collection_name;
		$res = $collection->findOne($condition,$field_name);
		return $res;
	}
	function db_count($collection_name,$condition)
	{
		global $db;
		$collection = $db->$collection_name;
		$res = $collection->count($condition);
		return $res;
	}
	function db_getMax($collection_name,$field_name)
	{
		global $db;
		$collection = $db->$collection_name;
		$res = $collection->find(array(),$field_name)->sort(array("_id"=>-1))->limit(1);
	
		foreach($res as $v)
		{
			return($v['id']);
		}
	}
	function db_find($collection_name,$field_name,$condition=null)
	{	
		global $db;
		$collection = $db->$collection_name;
		$res = $collection->find($condition,$field_name);	
		$output = "";
		$co=0;
		foreach($res as $v)
		{
			foreach($field_name as $p=>$k)
			{
				$output[$co][$p] = $v[$p];  
			}
		$co++;
		}
	return $output;
	}
}
?>