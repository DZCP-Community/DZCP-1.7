<?php
/**
 * <Hammermaps.de Libraries>
 * @package: DZCP Libraries for DZCP 1.7.x
 * @author: Hammermaps.de Developer Team
 * @link: http://www.hammermaps.de
 */

define('DZCPLibs', true);

//-> Neue PHP Liberty's oder Classen einbinden
if($libs_files = get_files(basePathHMLib.'/libs/',false,true,array('php'))) {
    foreach($libs_files AS $func)
    { require_once(basePathHMLib.'/libs/'.$func); }
    unset($libs_files,$func);
}