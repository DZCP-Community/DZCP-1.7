<?php
/**
 * <Hammermaps.de Libraries>
 * @package: DZCP Libraries for DZCP 1.7.x
 * @author: Hammermaps.de Developer Team
 * @link: http://www.hammermaps.de
 */

define('DZCPLibs', true);

//-> Neue PHP Liberty's oder Classen einbinden
if($libs_files = get_files(basePathHMLib.'/libs/',false,true,array('php'))) {
    foreach($libs_files AS $func)
    { require_once(basePathHMLib.'/libs/'.$func); }
    unset($libs_files,$func);
}

//-> Old API

/**
 * DZCP V1.7.0 -> 1.6.0.0
 * Decodiert Strings und Texte von UTF8.
 * Auslesen von Werten aus der Datenbank.
 *
 * @param string $txt
 * @return string
 */
function re($txt = '') {
    return stringParser::decode($txt);
}

/**
 * DZCP V1.7.0 -> 1.6.0.0
 * Codiert Strings und Texte in UTF8.
 * Schreiben von Werten in die Datenbank.
 *
 * @param string $txt
 * @return uft8 string
 */
function up($txt = '') {
    return stringParser::encode($txt);
}