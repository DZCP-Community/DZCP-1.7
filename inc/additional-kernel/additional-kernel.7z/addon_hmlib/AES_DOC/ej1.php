<?PHP
require_once('../AES128.php');
$aes=new AES128();
$aes->self_test();
?>