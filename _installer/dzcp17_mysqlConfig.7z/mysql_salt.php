<?php
$cryptkey = 'B2#pZ2$mQ6#e';