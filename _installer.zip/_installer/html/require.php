<table width="100%" cellpadding="3" cellspacing="1">
  <tr>
    <td class="head">&raquo;Optionale PHP-Erweiterungen</td>
  </tr>
  <tr>
    <td align="justify">
        Alle unten aufgelisteten PHP-Erweiterungen sollten zus&auml;tzlich installiert oder aktiviert werden.<br>
        Diese Erweiterungen wirken sich positiv auf die Sicherheit und Geschwindigkeit des CMS aus.
    </div>
    </td>
  </tr>
</table>