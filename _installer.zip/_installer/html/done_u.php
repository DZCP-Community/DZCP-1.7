<table width="100%" cellpadding="3" cellspacing="1">
  <tr>
    <td class="head">&raquo; Update erfolgreich abgeschlossen!</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      deV!L`z Clanportal wurde erfolgreich auf Ihrem Webserver auf die <b>Version <?php echo _version; ?></b> aktualisiert!<br /><br />
      <center><img src="img/done.jpg" border="0" alt=""></center><br />
      Als n&auml;chstes sollten Sie sich evtl. neu <a href="../news/">einloggen</a> und dem Adminmenu zuwenden um die Konfigurationen zu &uuml;berbearbeiten.<br /><br />
      <font color="red"><b>Wichtig!</b></font> Entfernen Sie unverz&uuml;glich den Installationsordner '<b>/_installer</b>' von Ihrem Webserver und setzen Sie <b>CHMOD 644</b> f&uuml;r die Datei <i>./inc/mysql.php</i>!<br />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nur so kann ein Schaden von Dritten ausgeschlossen werden.
      
    </td>
  </tr>
</table>