<table width="100%" cellpadding="3" cellspacing="1">
  <tr>
    <td colspan="5" class="head">&raquo; MySQL Datenbank</td>
  </tr>
  <tr>
    <td align="justify" colspan="6">
      Bitte geben Sie unten Ihre Zugangsdaten f&uuml;r die MySQL-Datenbank ein. Diese entnehmen Sie von Ihrem Provider.<br />
      Sobald die Testverbindung erfolgreich absolviert worden ist werden Sie aufgefordert die MySQL-Daten abzuspeichern.<br />
      Danach erscheint unten Rechts der Link zur Fortsetzung der Installation.
    </div>
    </td>
  </tr>
</table>