<table width="100%" cellpadding="3" cellspacing="1">
  <tr>
    <td class="head">&raquo; Dateirechte (CHMOD)</td>
  </tr>
  <tr>
    <td align="justify">
    Alle unten aufgelisteten Ordner und Dateien m&uuml;ssen Schreib- und Leserechte <b>777</b> besitzen!<br />
    <br />Am Ende der Seite besteht die M&ouml;glichkeit durch die Eingabe der FTP-Daten diese Rechte automatisch setzen zu lassen, was
    um einiges schneller geht als jeder Datei manuell die notwendigen Rechte zu verleihen.<br /><br />
    Sobald alle Dateirechte korrekt gesetzt wurden, erscheint unten rechts der Link zum fortfahren.</div>
    </td>
  </tr>
</table>