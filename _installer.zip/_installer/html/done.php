<table width="100%" cellpadding="3" cellspacing="1">
  <tr>
    <td class="head">&raquo; Installation erfolgreich abgeschlossen!</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      deV!L`z Clanportal wurde erfolgreich auf deinem Webserver installiert!<br /><br />
      <center><img src="img/done.jpg" border="0" alt=""></center><br />
      Als n&auml;chstes solltest du dich dem <a href="../admin/">Adminmenu</a> zuwenden um die Konfigurationen zu bearbeiten.<br /><br />
      <font color="red"><b>Wichtig!</b></font> Entferne bitte unverz&uuml;glich den Installationsordner '<b>/_installer</b>' von deinem Webserver und setze <b>CHMOD 644</b> f&uuml;r die Datei <i>./inc/mysql.php</i>!<br />
      Nur so kann ein Schaden von Dritten ausgeschlossen werden.
      
    </td>
  </tr>
</table>