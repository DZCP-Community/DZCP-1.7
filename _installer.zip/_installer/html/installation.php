<table width="100%" cellpadding="3" cellspacing="1">
  <tr>
    <td class="head" colspan="4">&raquo; Installation</td>
  </tr>
  <tr>
    <td colspan="4">
      Kommen wir zum nun zum letzten und abschlie&szlig;enden Teil der Installation.<br />
      F&uuml;llen Sie bitte <b>alle</b> Felder aus und klicken anschlie&szlig;end auf 'deV!L`z Clanportal installieren'.
      Mit den angegebenen Daten wird dann der erste Adminaccount eingerichtet, so das sie sofort loslegen k&ouml;nnen!
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>